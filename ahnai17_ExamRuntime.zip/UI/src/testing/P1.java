package testing;

import user_interface.Basic.UserInterface;

public class P1 {
	public static void main(String[] args) {
		UserInterface ui = new UserInterface();
		ui.open();
	}
}
