package testing;

import user_interface.Validation.UserInterface;

public class P5 {
	public static void main(String[] args) {
		UserInterface ui = new UserInterface();
		ui.open();
	}
}
