package testing;

import user_interface.Layout.UserInterface;

public class P2 {
	public static void main(String[] args) {
		UserInterface ui = new UserInterface();
		ui.open();
	}
}
