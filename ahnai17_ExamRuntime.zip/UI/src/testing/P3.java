package testing;

import user_interface.NestedLayout.UserInterface;

public class P3 {
	public static void main(String[] args) {
		UserInterface ui = new UserInterface();
		ui.open();
	}
}
