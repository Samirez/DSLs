package testing;

import user_interface.Elements.UserInterface;

public class P4 {
	public static void main(String[] args) {
		UserInterface ui = new UserInterface();
		ui.open();
	}
}
