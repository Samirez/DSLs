package testing;

import user_interface.MultipleForms.UserInterface;

public class P6 {
	public static void main(String[] args) {
		UserInterface ui = new UserInterface();
		ui.open();
	}
}
