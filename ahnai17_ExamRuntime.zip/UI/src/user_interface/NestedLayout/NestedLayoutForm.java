package user_interface.NestedLayout;
import javax.swing.*;
import java.awt.event.*;
import user_interface.common.*;

public class NestedLayoutForm extends Form{
	
	UserInterface parent;
	
	NestedLayoutForm(UserInterface parent){
		this.parent = parent;
	}
	
	public JPanel createPanel(){
		return createPanel0();
	}
	public JPanel createPanel0() {
		JPanel panel = new JPanel();
		panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

panel.add(createPanel1());

panel.add(createPanel2());
		
	return panel;
}

public JPanel createPanel1() {
	JPanel panel = new JPanel();
	panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
					
					
	return panel;
}				

public JPanel createPanel2() {
	JPanel panel = new JPanel();
	panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
					
					
	return panel;
}				
	public boolean checkValidity(){
		return true;
	}		
}
