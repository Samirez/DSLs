package user_interface.NestedLayout;
import javax.swing.*;

public class UserInterface{
	public JFrame frame;
	
	public void open(){
		frame = new JFrame("NestedLayout");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		NestedLayoutForm form = new NestedLayoutForm(this);
		frame.add(form.createPanel());
		frame.pack();
		frame.setVisible(true);
		
	}
}
