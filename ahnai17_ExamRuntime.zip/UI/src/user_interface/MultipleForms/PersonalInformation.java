package user_interface.MultipleForms;
import javax.swing.*;
import java.awt.event.*;
import user_interface.common.*;

public class PersonalInformation extends Form{
	UserInterface parent;

public PersonalInformation () {
	
}

public PersonalInformation(UserInterface userInterface){
							
}


	

	public void PersonalInformationForm(UserInterface parent){
		this.parent = parent;
	}
	public JPanel createPanel(){
		return createPanel0();
	}
	
	
	public JPanel createPanel0() {
		JPanel panel = new JPanel();
		panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
		String name = "";
		panel.add(new JLabel((("Fill with "+ name)+" Information")));
		
		InterestForm InterestForm = new InterestForm();
		panel.add(InterestForm.createPanel());
		return panel;
	}
	public boolean checkValidity(){
		
		return true;	
	}					
}

