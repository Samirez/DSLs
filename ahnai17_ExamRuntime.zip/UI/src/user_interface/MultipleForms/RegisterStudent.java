package user_interface.MultipleForms;
import javax.swing.*;
import java.awt.event.*;
import user_interface.common.*;

public class RegisterStudent extends Form{
	UserInterface parent;

public RegisterStudent () {
	
}

public RegisterStudent(UserInterface userInterface){
							
}



public JButton saveComponent;

public RegisterStudent(UserInterface parent0, String string){

}
public RegisterStudent(UserInterface parent0, int x, int y){

}		
	

	public void RegisterStudentForm(UserInterface parent){
		this.parent = parent;

saveComponent = new JButton("Save");
	}
	public JPanel createPanel(){
		return createPanel0();
	}
	
	
	public JPanel createPanel0() {
		JPanel panel = new JPanel();
		panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
		
		PersonalInformation PersonalInformation = new PersonalInformation(parent, "Student");
		panel.add(PersonalInformation.createPanel());
		UniversityInformation UniversityInformation = new UniversityInformation(parent, 3, 10);
		panel.add(UniversityInformation.createPanel());
		panel.add(saveComponent);
		saveComponent.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				if(checkValidity()){
					JOptionPane.showMessageDialog(
						parent.frame,
						"Data has been save");
				}
				else {
					JOptionPane.showMessageDialog(
						parent.frame,
						"Validation error",
						"Error",
						JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		return panel;
	}
	public boolean checkValidity(){
		
		return true;	
	}					
}

