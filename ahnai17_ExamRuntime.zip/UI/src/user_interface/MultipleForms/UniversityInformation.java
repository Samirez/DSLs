package user_interface.MultipleForms;
import javax.swing.*;
import java.awt.event.*;
import user_interface.common.*;

public class UniversityInformation extends Form{
	UserInterface parent;

public UniversityInformation () {
	
}

public UniversityInformation(UserInterface userInterface){
							
}

public UniversityInformation(UserInterface user, int i, int j){
		
}		


	

	public void UniversityInformationForm(UserInterface parent){
		this.parent = parent;
	}
	public JPanel createPanel(){
		return createPanel0();
	}
	
	
	public JPanel createPanel0() {
		JPanel panel = new JPanel();
		panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
		
		return panel;
	}
	public boolean checkValidity(){
		
		return true;	
	}					
}

