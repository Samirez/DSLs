package user_interface.MultipleForms;
import javax.swing.*;

public class UserInterface{
	public JFrame frame;
	
	public void open(){
		frame = new JFrame("MultipleForms");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		RegisterStudent form = new RegisterStudent(this);
		frame.add(form.createPanel());
		frame.pack();
		frame.setVisible(true);
		
	}
}
