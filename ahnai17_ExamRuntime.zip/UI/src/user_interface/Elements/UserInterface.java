package user_interface.Elements;
import javax.swing.*;

public class UserInterface{
	public JFrame frame;
	
	public void open(){
		frame = new JFrame("Elements");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		ElementsForm form = new ElementsForm(this);
		frame.add(form.createPanel());
		frame.pack();
		frame.setVisible(true);
		
	}
}
