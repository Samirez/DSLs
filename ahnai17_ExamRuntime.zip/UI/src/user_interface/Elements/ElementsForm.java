package user_interface.Elements;
import javax.swing.*;
import java.awt.event.*;
import user_interface.common.*;

public class ElementsForm extends Form{
	
	UserInterface parent;

public JTextField nameComponent;

public JButton saveComponent;
	
	ElementsForm(UserInterface parent){
		this.parent = parent;
saveComponent = new JButton("Valid");
		nameComponent = new JTextField();
	}
	
	public JPanel createPanel(){
		return createPanel0();
	}
	public JPanel createPanel0() {
		JPanel panel = new JPanel();
		panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
		
		panel.add(nameComponent);
		panel.add(saveComponent);
	return panel;
}
	public boolean checkValidity(){
	String	name = this.nameComponent.getText();
	
	
		return true;
	}		
}
