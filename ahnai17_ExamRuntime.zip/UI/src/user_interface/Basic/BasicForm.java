package user_interface.Basic;
import javax.swing.*;
import java.awt.event.*;
import user_interface.common.*;

public class BasicForm extends Form{
	
	UserInterface parent;
	
	BasicForm(UserInterface parent){
		this.parent = parent;
	}
	
	public JPanel createPanel(){
		return createPanel0();
	}
	public JPanel createPanel0() {
		JPanel panel = new JPanel();
		panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
		
	return panel;
}
	public boolean checkValidity(){
		return true;
	}		
}
