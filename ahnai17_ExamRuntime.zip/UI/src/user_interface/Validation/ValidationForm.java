package user_interface.Validation;
import javax.swing.*;
import java.awt.event.*;
import user_interface.common.*;

public class ValidationForm extends Form{
	
	UserInterface parent;

public JTextField nameComponent;

public JTextField ageComponent;

public JTextField passwordComponent;

public JTextField repeatPasswordComponent;

public JButton saveComponent;

public JButton cancelComponent;
	
	ValidationForm(UserInterface parent){
		this.parent = parent;
saveComponent = new JButton("Save");
cancelComponent = new JButton("Cancel");
		nameComponent = new JTextField();
		ageComponent = new JTextField();
		passwordComponent = new JTextField();
		repeatPasswordComponent = new JTextField();
	}
	
	public JPanel createPanel(){
		return createPanel0();
	}
	public JPanel createPanel0() {
		JPanel panel = new JPanel();
		panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

panel.add(createPanel1());

panel.add(createPanel2());

panel.add(createPanel3());

panel.add(createPanel4());

panel.add(createPanel5());
	return panel;
}

public JPanel createPanel1() {
	JPanel panel = new JPanel();
	panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
					
					panel.add(nameComponent);
	return panel;
}				

public JPanel createPanel2() {
	JPanel panel = new JPanel();
	panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
					
					panel.add(ageComponent);
	return panel;
}				

public JPanel createPanel3() {
	JPanel panel = new JPanel();
	panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
					
					panel.add(passwordComponent);
	return panel;
}				

public JPanel createPanel4() {
	JPanel panel = new JPanel();
	panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
					
					panel.add(repeatPasswordComponent);
	return panel;
}				

public JPanel createPanel5() {
	JPanel panel = new JPanel();
	panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
					panel.add(saveComponent);
					saveComponent.addActionListener(new ActionListener(){
						public void actionPerformed(ActionEvent e){
							if(checkValidity()){
								JOptionPane.showMessageDialog(
									parent.frame,
									"Data has been save");
							}
							else {
								JOptionPane.showMessageDialog(
									parent.frame,
									"Validation error",
									"Error",
									JOptionPane.ERROR_MESSAGE);
							}
						}
					});
					panel.add(cancelComponent);
	return panel;
}				
	public boolean checkValidity(){
	String	name = this.nameComponent.getText();
	
	int age = 0;
	try { 
		 age = Integer.parseInt(this.ageComponent.getText());
		 if(!((age > 18) && (age <= 75))){
		 	return false;
		 }
	} catch (Exception ex){
		return false;
	}	
	String password = this.passwordComponent.getText();
	String	repeatPassword = this.repeatPasswordComponent.getText();
	
	
	if (!(password).equals(repeatPassword)){
			return false;	
		}
		return true;
	}		
}
