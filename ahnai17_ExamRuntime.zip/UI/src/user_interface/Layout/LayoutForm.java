package user_interface.Layout;
import javax.swing.*;
import java.awt.event.*;
import user_interface.common.*;

public class LayoutForm extends Form{
	
	UserInterface parent;
	
	LayoutForm(UserInterface parent){
		this.parent = parent;
	}
	
	public JPanel createPanel(){
		return createPanel0();
	}
	public JPanel createPanel0() {
		JPanel panel = new JPanel();
		panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
		
		
	return panel;
}
	public boolean checkValidity(){
		return true;
	}		
}
